#include<iostream>
#include<glad/glad.h>
#include<GLFW/glfw3.h>

int main() {
    std::cout << "It works fifdfsdfnally";
    return 0;
}